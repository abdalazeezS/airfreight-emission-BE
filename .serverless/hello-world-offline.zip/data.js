const data = [
  {
    "id": 1,
    "emission_level": 90,
    "origin": "Kayes",
    "destination": "Cincinnati",
    "airline ": "Pimenta Bueno Airport",
    "start_date": "10/06/2024",
    "end_date": "27/04/2026"
  },
  {
    "id": 2,
    "emission_level": 105,
    "origin": "Hongtang",
    "destination": "Varāmīn",
    "airline ": "Brisbane International Airport",
    "start_date": "27/10/2023",
    "end_date": "28/09/2024"
  },
  {
    "id": 3,
    "emission_level": 147,
    "origin": "Lefkoniko",
    "destination": "Portel",
    "airline ": "Melinda Airport",
    "start_date": "05/01/2024",
    "end_date": "19/02/2024"
  },
  {
    "id": 4,
    "emission_level": 78,
    "origin": "Yangba",
    "destination": "Quivilla",
    "airline ": "Beni Airport",
    "start_date": "24/10/2023",
    "end_date": "04/04/2024"
  },
  {
    "id": 5,
    "emission_level": 31,
    "origin": "Gaofeng",
    "destination": "Yihe",
    "airline ": "Yanji Chaoyangchuan Airport",
    "start_date": "20/01/2024",
    "end_date": "01/08/2025"
  },
  {
    "id": 6,
    "emission_level": 34,
    "origin": "Alimono",
    "destination": "Jiuguan",
    "airline ": "Neumünster Airport",
    "start_date": "09/02/2024",
    "end_date": "15/11/2025"
  },
  {
    "id": 7,
    "emission_level": 65,
    "origin": "Tawau",
    "destination": "Castillos",
    "airline ": "Aseki Airport",
    "start_date": "19/02/2024",
    "end_date": "22/12/2025"
  },
  {
    "id": 8,
    "emission_level": 95,
    "origin": "Falun",
    "destination": "Ili",
    "airline ": "Hartsfield Jackson Atlanta International Airport",
    "start_date": "29/06/2024",
    "end_date": "09/01/2026"
  },
  {
    "id": 9,
    "emission_level": 135,
    "origin": "Manokwari",
    "destination": "Kolpashevo",
    "airline ": "Trunojoyo Airport",
    "start_date": "24/08/2024",
    "end_date": "25/03/2025"
  },
  {
    "id": 10,
    "emission_level": 26,
    "origin": "Mohelnice",
    "destination": "Jacura",
    "airline ": "Spring Creek Airport",
    "start_date": "13/10/2023",
    "end_date": "11/01/2026"
  },
  {
    "id": 11,
    "emission_level": 79,
    "origin": "Värnamo",
    "destination": "That Phanom",
    "airline ": "Fascene Airport",
    "start_date": "01/09/2024",
    "end_date": "03/02/2025"
  },
  {
    "id": 12,
    "emission_level": 73,
    "origin": "Miami",
    "destination": "Ibarra",
    "airline ": "Sub Teniente Nestor Arias Airport",
    "start_date": "25/04/2024",
    "end_date": "07/05/2024"
  },
  {
    "id": 13,
    "emission_level": 46,
    "origin": "Barbosa",
    "destination": "Gradec",
    "airline ": "Hopedale Airport",
    "start_date": "03/01/2024",
    "end_date": "25/11/2024"
  },
  {
    "id": 14,
    "emission_level": 57,
    "origin": "Göteborg",
    "destination": "Inhambane",
    "airline ": "Cabo F.A.A. H. R. Bordón Airport",
    "start_date": "27/07/2024",
    "end_date": "08/12/2023"
  },
  {
    "id": 15,
    "emission_level": 21,
    "origin": "Bangkalan",
    "destination": "Kadipaten",
    "airline ": "Vanimo Airport",
    "start_date": "07/06/2024",
    "end_date": "29/05/2025"
  },
  {
    "id": 16,
    "emission_level": 96,
    "origin": "Staromyshastovskaya",
    "destination": "Goris",
    "airline ": "Tanjung Santan Airport",
    "start_date": "28/05/2024",
    "end_date": "06/03/2024"
  },
  {
    "id": 17,
    "emission_level": 95,
    "origin": "Shuikou",
    "destination": "Phoenix",
    "airline ": "Ivanof Bay Seaplane Base",
    "start_date": "15/07/2024",
    "end_date": "14/12/2024"
  },
  {
    "id": 18,
    "emission_level": 73,
    "origin": "Villa Santa Rita",
    "destination": "Bangus Kulon",
    "airline ": "Toulouse-Blagnac Airport",
    "start_date": "10/11/2023",
    "end_date": "28/12/2023"
  },
  {
    "id": 19,
    "emission_level": 69,
    "origin": "Kertahayu",
    "destination": "Slovenske Konjice",
    "airline ": "Sheremetyevo International Airport",
    "start_date": "23/04/2024",
    "end_date": "06/10/2023"
  },
  {
    "id": 20,
    "emission_level": 140,
    "origin": "Goussainville",
    "destination": "Balky",
    "airline ": "Bukhovtsi Airfield",
    "start_date": "12/02/2024",
    "end_date": "17/06/2025"
  },
  {
    "id": 21,
    "emission_level": 134,
    "origin": "Antagan Segunda",
    "destination": "Laholm",
    "airline ": "Aragarças Airport",
    "start_date": "18/07/2024",
    "end_date": "27/12/2025"
  },
  {
    "id": 22,
    "emission_level": 47,
    "origin": "Vale Boeiro",
    "destination": "Huaqiao",
    "airline ": "Julius Nyerere International Airport",
    "start_date": "04/02/2024",
    "end_date": "21/04/2026"
  },
  {
    "id": 23,
    "emission_level": 97,
    "origin": "Pakemitan Dua",
    "destination": "Byczyna",
    "airline ": "Fahud Airport",
    "start_date": "18/04/2024",
    "end_date": "30/03/2025"
  },
  {
    "id": 24,
    "emission_level": 71,
    "origin": "Longtian",
    "destination": "La Garenne-Colombes",
    "airline ": "Liberal Mid-America Regional Airport",
    "start_date": "16/09/2024",
    "end_date": "14/12/2025"
  },
  {
    "id": 25,
    "emission_level": 57,
    "origin": "Saint-Eustache",
    "destination": "Girijaya",
    "airline ": "Z M Jack Stell Field",
    "start_date": "26/07/2024",
    "end_date": "09/10/2023"
  },
  {
    "id": 26,
    "emission_level": 113,
    "origin": "Pinega",
    "destination": "Ngadipuro",
    "airline ": "Woodward Field",
    "start_date": "30/12/2023",
    "end_date": "29/07/2026"
  },
  {
    "id": 27,
    "emission_level": 97,
    "origin": "Kijini",
    "destination": "Camperdown",
    "airline ": "Siirt Airport",
    "start_date": "15/06/2024",
    "end_date": "02/10/2023"
  },
  {
    "id": 28,
    "emission_level": 86,
    "origin": "Xike",
    "destination": "Santiago de Chuco",
    "airline ": "Ust-Tsylma Airport",
    "start_date": "09/01/2024",
    "end_date": "29/09/2024"
  },
  {
    "id": 29,
    "emission_level": 33,
    "origin": "Mahdalynivka",
    "destination": "Jinji",
    "airline ": "Kotoka International Airport",
    "start_date": "07/07/2024",
    "end_date": "21/08/2024"
  },
  {
    "id": 30,
    "emission_level": 45,
    "origin": "Dalmeny",
    "destination": "Paraiso",
    "airline ": "Boulder Municipal Airport",
    "start_date": "17/05/2024",
    "end_date": "06/03/2025"
  },
  {
    "id": 31,
    "emission_level": 87,
    "origin": "Cepões",
    "destination": "Hengzhou",
    "airline ": "Capital City Airport",
    "start_date": "11/07/2024",
    "end_date": "10/03/2024"
  },
  {
    "id": 32,
    "emission_level": 40,
    "origin": "Vinica",
    "destination": "Balongmulyo",
    "airline ": "Santa Ynez Airport",
    "start_date": "17/06/2024",
    "end_date": "07/01/2025"
  },
  {
    "id": 33,
    "emission_level": 109,
    "origin": "Santana do Paraíso",
    "destination": "Gaoqiaolou",
    "airline ": "La Grande-3 Airport",
    "start_date": "28/08/2024",
    "end_date": "04/05/2026"
  },
  {
    "id": 34,
    "emission_level": 107,
    "origin": "Phumĭ Véal Srê",
    "destination": "Henggang",
    "airline ": "Sharjah International Airport",
    "start_date": "02/12/2023",
    "end_date": "12/08/2024"
  },
  {
    "id": 35,
    "emission_level": 101,
    "origin": "San Antonio",
    "destination": "Qiashui",
    "airline ": "Ed-Air Airport",
    "start_date": "26/02/2024",
    "end_date": "20/07/2026"
  },
  {
    "id": 36,
    "emission_level": 43,
    "origin": "Gostivar",
    "destination": "Obršani",
    "airline ": "Mount Hotham Airport",
    "start_date": "21/04/2024",
    "end_date": "31/12/2024"
  },
  {
    "id": 37,
    "emission_level": 98,
    "origin": "Songnan",
    "destination": "Cikandang",
    "airline ": "Cedar City Regional Airport",
    "start_date": "17/01/2024",
    "end_date": "02/11/2024"
  },
  {
    "id": 38,
    "emission_level": 103,
    "origin": "Ishimbay",
    "destination": "Indralayang",
    "airline ": "Wollongong Airport",
    "start_date": "12/07/2024",
    "end_date": "08/08/2025"
  },
  {
    "id": 39,
    "emission_level": 46,
    "origin": "Kiełczów",
    "destination": "Iperó",
    "airline ": "Pama Airport",
    "start_date": "19/11/2023",
    "end_date": "31/10/2024"
  },
  {
    "id": 40,
    "emission_level": 50,
    "origin": "Kurunegala",
    "destination": "San José de Jáchal",
    "airline ": "Casa Grande Municipal Airport",
    "start_date": "17/03/2024",
    "end_date": "04/06/2024"
  },
  {
    "id": 41,
    "emission_level": 74,
    "origin": "Filipowice",
    "destination": "Stockholm",
    "airline ": "Mettel Field",
    "start_date": "08/06/2024",
    "end_date": "25/10/2025"
  },
  {
    "id": 42,
    "emission_level": 38,
    "origin": "Sancti Spíritus",
    "destination": "Krasnapollye",
    "airline ": "Billings Logan International Airport",
    "start_date": "25/03/2024",
    "end_date": "20/02/2025"
  },
  {
    "id": 43,
    "emission_level": 84,
    "origin": "Potosí",
    "destination": "Hongwei",
    "airline ": "Miami University Airport",
    "start_date": "23/02/2024",
    "end_date": "05/04/2025"
  },
  {
    "id": 44,
    "emission_level": 22,
    "origin": "Sykiés",
    "destination": "Bollnäs",
    "airline ": "Tanbar Airport",
    "start_date": "30/03/2024",
    "end_date": "03/04/2025"
  },
  {
    "id": 45,
    "emission_level": 110,
    "origin": "Quảng Yên",
    "destination": "Khvorostyanka",
    "airline ": "Guanacaste Airport",
    "start_date": "04/06/2024",
    "end_date": "28/03/2026"
  },
  {
    "id": 46,
    "emission_level": 96,
    "origin": "Cesson-Sévigné",
    "destination": "Kut Rang",
    "airline ": "Paris Beauvais Tillé Airport",
    "start_date": "04/12/2023",
    "end_date": "20/06/2025"
  },
  {
    "id": 47,
    "emission_level": 93,
    "origin": "Kosan",
    "destination": "Tournai",
    "airline ": "Minangkabau International Airport",
    "start_date": "26/03/2024",
    "end_date": "02/09/2025"
  },
  {
    "id": 48,
    "emission_level": 49,
    "origin": "Pokrov",
    "destination": "Stockholm",
    "airline ": "Aniwa Airport",
    "start_date": "26/02/2024",
    "end_date": "27/07/2026"
  },
  {
    "id": 49,
    "emission_level": 149,
    "origin": "São Joaquim",
    "destination": "Handan",
    "airline ": "Talagi Airport",
    "start_date": "18/10/2023",
    "end_date": "08/11/2023"
  },
  {
    "id": 50,
    "emission_level": 85,
    "origin": "Łapanów",
    "destination": "Luka nad Jihlavou",
    "airline ": "Jeh Airport",
    "start_date": "28/05/2024",
    "end_date": "03/02/2025"
  },
  {
    "id": 51,
    "emission_level": 68,
    "origin": "Agenebode",
    "destination": "Francisco I Madero",
    "airline ": "Dimbokro Airport",
    "start_date": "09/10/2023",
    "end_date": "28/05/2026"
  },
  {
    "id": 52,
    "emission_level": 65,
    "origin": "Keputran",
    "destination": "Fuying",
    "airline ": "Maradi Airport",
    "start_date": "14/04/2024",
    "end_date": "17/02/2025"
  },
  {
    "id": 53,
    "emission_level": 72,
    "origin": "Negla",
    "destination": "Hetan",
    "airline ": "Dix-Sept Rosado Airport",
    "start_date": "11/06/2024",
    "end_date": "02/11/2024"
  },
  {
    "id": 54,
    "emission_level": 67,
    "origin": "Solna",
    "destination": "Troyes",
    "airline ": "Aratika Nord Airport",
    "start_date": "14/05/2024",
    "end_date": "30/07/2026"
  },
  {
    "id": 55,
    "emission_level": 20,
    "origin": "Nowe Miasto",
    "destination": "Wujing",
    "airline ": "Sydney Bankstown Airport",
    "start_date": "24/04/2024",
    "end_date": "06/03/2025"
  },
  {
    "id": 56,
    "emission_level": 142,
    "origin": "Daszewice",
    "destination": "Ergong",
    "airline ": "Ontario Municipal Airport",
    "start_date": "04/09/2024",
    "end_date": "08/06/2024"
  },
  {
    "id": 57,
    "emission_level": 119,
    "origin": "Samanco",
    "destination": "Bang Krathum",
    "airline ": "Touho Airport",
    "start_date": "02/09/2024",
    "end_date": "10/02/2025"
  },
  {
    "id": 58,
    "emission_level": 150,
    "origin": "Nungwi",
    "destination": "Yegorlykskaya",
    "airline ": "Berlin Brandenburg Airport (U.C.)",
    "start_date": "27/04/2024",
    "end_date": "22/04/2025"
  },
  {
    "id": 59,
    "emission_level": 148,
    "origin": "Ust’-Labinsk",
    "destination": "Paloh",
    "airline ": "Peretola Airport",
    "start_date": "22/09/2024",
    "end_date": "02/01/2025"
  },
  {
    "id": 60,
    "emission_level": 121,
    "origin": "San Carlos",
    "destination": "Miðvágur",
    "airline ": "Tokachi-Obihiro Airport",
    "start_date": "02/06/2024",
    "end_date": "05/01/2025"
  },
  {
    "id": 61,
    "emission_level": 147,
    "origin": "Itapetininga",
    "destination": "Oitui",
    "airline ": "King Salman Abdulaziz Airport",
    "start_date": "18/12/2023",
    "end_date": "02/05/2025"
  },
  {
    "id": 62,
    "emission_level": 88,
    "origin": "Acolla",
    "destination": "Chabařovice",
    "airline ": "Ord River Airport",
    "start_date": "11/06/2024",
    "end_date": "18/04/2024"
  },
  {
    "id": 63,
    "emission_level": 138,
    "origin": "Annapolis",
    "destination": "Qingshan",
    "airline ": "Sligo Airport",
    "start_date": "27/12/2023",
    "end_date": "02/03/2025"
  },
  {
    "id": 64,
    "emission_level": 35,
    "origin": "Guadalupe",
    "destination": "Kirovsk",
    "airline ": "Châteauroux-Déols \"Marcel Dassault\" Airport",
    "start_date": "20/04/2024",
    "end_date": "24/10/2024"
  },
  {
    "id": 65,
    "emission_level": 117,
    "origin": "La Loma",
    "destination": "Xianghe",
    "airline ": "Diomício Freitas Airport",
    "start_date": "28/05/2024",
    "end_date": "28/02/2026"
  },
  {
    "id": 66,
    "emission_level": 139,
    "origin": "Padangtikar",
    "destination": "Tangxian",
    "airline ": "Hanamaki Airport",
    "start_date": "22/04/2024",
    "end_date": "27/06/2024"
  },
  {
    "id": 67,
    "emission_level": 39,
    "origin": "Liulin",
    "destination": "Anguera",
    "airline ": "Santana Ramos Airport",
    "start_date": "04/05/2024",
    "end_date": "14/05/2025"
  },
  {
    "id": 68,
    "emission_level": 48,
    "origin": "Tô Hạp",
    "destination": "Natividade",
    "airline ": "Kalskag Airport",
    "start_date": "06/09/2024",
    "end_date": "26/01/2024"
  },
  {
    "id": 69,
    "emission_level": 87,
    "origin": "Tajao",
    "destination": "Nankou",
    "airline ": "Grande Cache Airport",
    "start_date": "30/07/2024",
    "end_date": "27/07/2024"
  },
  {
    "id": 70,
    "emission_level": 98,
    "origin": "Gwio Kura",
    "destination": "Corinto",
    "airline ": "Pilot Station Airport",
    "start_date": "19/03/2024",
    "end_date": "27/08/2025"
  },
  {
    "id": 71,
    "emission_level": 72,
    "origin": "Bujanovac",
    "destination": "Kokoshkino",
    "airline ": "Sandstone Airport",
    "start_date": "03/02/2024",
    "end_date": "18/06/2026"
  },
  {
    "id": 72,
    "emission_level": 124,
    "origin": "Kommunisticheskiy",
    "destination": "Ocumare del Tuy",
    "airline ": "San Javier Airport",
    "start_date": "14/04/2024",
    "end_date": "16/05/2024"
  },
  {
    "id": 73,
    "emission_level": 110,
    "origin": "Huaylillas",
    "destination": "Szolnok",
    "airline ": "Kindersley Airport",
    "start_date": "16/06/2024",
    "end_date": "19/04/2024"
  },
  {
    "id": 74,
    "emission_level": 112,
    "origin": "Bandung",
    "destination": "Niopanda",
    "airline ": "Bykovo Airport",
    "start_date": "16/11/2023",
    "end_date": "11/05/2024"
  },
  {
    "id": 75,
    "emission_level": 139,
    "origin": "Bulakbanjar",
    "destination": "Velyka Oleksandrivka",
    "airline ": "Casiguran Airport",
    "start_date": "24/03/2024",
    "end_date": "31/03/2024"
  },
  {
    "id": 76,
    "emission_level": 87,
    "origin": "Songshan",
    "destination": "Krynice",
    "airline ": "Tekirdağ Çorlu Airport",
    "start_date": "09/03/2024",
    "end_date": "31/12/2024"
  },
  {
    "id": 77,
    "emission_level": 48,
    "origin": "Abu Dhabi",
    "destination": "Baton Rouge",
    "airline ": "Buzzards Point Seaplane Base",
    "start_date": "13/10/2023",
    "end_date": "13/01/2026"
  },
  {
    "id": 78,
    "emission_level": 33,
    "origin": "Quận Bốn",
    "destination": "Gradec",
    "airline ": "Sigonella Navy Air Base",
    "start_date": "26/05/2024",
    "end_date": "07/05/2024"
  },
  {
    "id": 79,
    "emission_level": 70,
    "origin": "Xingxi",
    "destination": "Kosamphi Nakhon",
    "airline ": "Tambolaka Airport",
    "start_date": "06/09/2024",
    "end_date": "10/03/2025"
  },
  {
    "id": 80,
    "emission_level": 147,
    "origin": "Shuitian",
    "destination": "Laï",
    "airline ": "Greenlee County Airport",
    "start_date": "27/04/2024",
    "end_date": "11/10/2024"
  },
  {
    "id": 81,
    "emission_level": 23,
    "origin": "Peterborough",
    "destination": "Vrakháti",
    "airline ": "Ilford Airport",
    "start_date": "21/10/2023",
    "end_date": "06/12/2024"
  },
  {
    "id": 82,
    "emission_level": 53,
    "origin": "Novomykolayivka",
    "destination": "Singaraja",
    "airline ": "Kitadaito Airport",
    "start_date": "18/02/2024",
    "end_date": "04/01/2025"
  },
  {
    "id": 83,
    "emission_level": 29,
    "origin": "Qingshan",
    "destination": "Keratéa",
    "airline ": "Mariupol International Airport",
    "start_date": "07/04/2024",
    "end_date": "04/01/2025"
  },
  {
    "id": 84,
    "emission_level": 26,
    "origin": "Yujia",
    "destination": "Dongling",
    "airline ": "Novo Hamburgo Airport",
    "start_date": "16/07/2024",
    "end_date": "08/11/2024"
  },
  {
    "id": 85,
    "emission_level": 88,
    "origin": "Kaset Sombun",
    "destination": "Yajiang",
    "airline ": "Aerotortuguero Airport",
    "start_date": "26/08/2024",
    "end_date": "16/11/2023"
  },
  {
    "id": 86,
    "emission_level": 86,
    "origin": "Cigadog",
    "destination": "Las Higueras",
    "airline ": "Capitan V A Almonacid Airport",
    "start_date": "23/10/2023",
    "end_date": "26/12/2024"
  },
  {
    "id": 87,
    "emission_level": 116,
    "origin": "Hongos",
    "destination": "Xi’an",
    "airline ": "Myrhorod Air Base",
    "start_date": "11/05/2024",
    "end_date": "25/04/2026"
  },
  {
    "id": 88,
    "emission_level": 83,
    "origin": "Chrást",
    "destination": "Nikitinskiy",
    "airline ": "Benton Field",
    "start_date": "21/11/2023",
    "end_date": "04/03/2024"
  },
  {
    "id": 89,
    "emission_level": 98,
    "origin": "Iwakura",
    "destination": "Albacete",
    "airline ": "Castlereagh Lake Seaplane Base",
    "start_date": "26/12/2023",
    "end_date": "04/12/2025"
  },
  {
    "id": 90,
    "emission_level": 71,
    "origin": "Baranoa",
    "destination": "Ancasti",
    "airline ": "Kokonau Airport",
    "start_date": "24/08/2024",
    "end_date": "04/10/2024"
  },
  {
    "id": 91,
    "emission_level": 103,
    "origin": "Loučná nad Desnou",
    "destination": "Huangqiao",
    "airline ": "Burns Municipal Airport",
    "start_date": "13/12/2023",
    "end_date": "14/10/2025"
  },
  {
    "id": 92,
    "emission_level": 143,
    "origin": "Yelizavetino",
    "destination": "Watoona",
    "airline ": "Chevak Airport",
    "start_date": "28/02/2024",
    "end_date": "26/06/2025"
  },
  {
    "id": 93,
    "emission_level": 109,
    "origin": "Xiaolan",
    "destination": "Castlemartyr",
    "airline ": "Takamatsu Airport",
    "start_date": "13/01/2024",
    "end_date": "28/01/2024"
  },
  {
    "id": 94,
    "emission_level": 126,
    "origin": "Ibirataia",
    "destination": "Dębica",
    "airline ": "Tri Cities Airport",
    "start_date": "25/08/2024",
    "end_date": "28/01/2025"
  },
  {
    "id": 95,
    "emission_level": 107,
    "origin": "Paris 11",
    "destination": "Donggu",
    "airline ": "Joplin Regional Airport",
    "start_date": "06/03/2024",
    "end_date": "11/05/2024"
  },
  {
    "id": 96,
    "emission_level": 41,
    "origin": "Ševica",
    "destination": "Krechevitsy",
    "airline ": "Lake Tahoe Airport",
    "start_date": "17/09/2024",
    "end_date": "11/10/2025"
  },
  {
    "id": 97,
    "emission_level": 95,
    "origin": "Sosnovyy Bor",
    "destination": "Hikari",
    "airline ": "Walcha Airport",
    "start_date": "13/03/2024",
    "end_date": "12/04/2025"
  },
  {
    "id": 98,
    "emission_level": 126,
    "origin": "Waihibar",
    "destination": "Mari",
    "airline ": "New Moon Airport",
    "start_date": "17/05/2024",
    "end_date": "08/08/2024"
  },
  {
    "id": 99,
    "emission_level": 45,
    "origin": "Daojiang",
    "destination": "Matelândia",
    "airline ": "Marlboro Airport",
    "start_date": "04/05/2024",
    "end_date": "18/11/2024"
  },
  {
    "id": 100,
    "emission_level": 135,
    "origin": "Anding",
    "destination": "Wonosari",
    "airline ": "Sunriver Airport",
    "start_date": "03/10/2023",
    "end_date": "17/12/2025"
  }
];

export { data };