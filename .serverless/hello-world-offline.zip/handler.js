import express from 'express';
import serverless from 'serverless-http';
import { data } from './data.js';
const app = express();

app.get('/trips', (req, res) => {
  // const searchTerm = req.query.search;
  // const filterAge = req.query.age;

  // let filteredData = data;

  // if (searchTerm) {
  //   filteredData = filteredData.filter(user => user.name.includes(searchTerm));
  // }

  // if (filterAge) {
  //   filteredData = filteredData.filter(user => user.age >= filterAge);
  // }

  res.status(200).send('hi').end();
});

const handler = serverless(app);
export { handler };